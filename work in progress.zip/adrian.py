while True:
    a0 = input("Skriv tallet du vil finne: ")
    
    a0 = a0.replace(",", "")

    a1 = int(a0)

    mengde = len(a0)

    dog = a1

    while True:
        print(dog)
        if dog % 10**mengde == a1 and a1 != dog:
            print(" ")
            print(dog, "slutter med", a0)
            print("det tok", dog/a1, "forsøk")
            break
        else:
            dog += a1