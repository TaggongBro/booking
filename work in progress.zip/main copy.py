from flask import Flask, render_template, url_for, request
import pymongo
import time
from datetime import datetime
from dateutil.relativedelta import relativedelta

app = Flask(__name__)

current_datetime = datetime.now()

current_date = datetime.now().strftime("%d-%m-%Y")



#@app.route("/")
#def webside():
    #return render_template("index.html")

#app.run()

#name = request.form["name"]

client = pymongo.MongoClient("mongodb+srv://danbar:Geforce420@cluster0.jbkzgrx.mongodb.net/?retryWrites=true&w=majority")

db = client["dan"]
userbase = db["dancollect"]
roombase = db["rooms"]

roomchecker = roombase.find()

def create():
    print(" ")
    print("-Creation Tool-")
    print("")
    room_id = input("Nytt rom navn: ")
    room_status = input("Set status: ")
    new_room = {"roomname": room_id, "status": room_status, "booked": 0}
    roombase.insert_one(new_room)
    print("User registered successfully.")
    rent()

def rent():
    print("---------------")
    print("-Rent et rom-")
    print("")
    print("Skriv bokstaven på rommet du vil booke")
    for x in roomchecker:
        print(x["roomname"], "rommet", "er", x["status"])
    print("")
    valg = input("> ")
    theRoom = roombase.find_one({"roomname": valg.upper()})

    if theRoom["status"] == "opptatt":
        print(valg + " rommet er opptatt, du kan ikke booke det")
        print("Prøv på nytt")
        time.sleep(3)
        rent()
    query = {"roomname": valg}
    ny_verdi = {"$set": {"status": "opptatt"}}
    roombase.update_one(query, ny_verdi)
    print("-Skriv dato du skal booke-")
    print("Nåværende dato: " + str(current_date))    
    print(" ")

    month = input("Måned: ")
    while True:
        if month == month>12:
            print("Du kan ikke velge noe høyere en 12, vi har bare 12 måneder")
        else:
            break

        day = input("Dag: ")
    while True:
        if month % 2 == 1:
            if day == day>31:
                print("Du kan ikke velge noe høyere en 31")
        else:
            
            break


    #gammel_verdi = {"$set", "roomname": valg, "status": "Ledig"}
    #ny_verdi = {"$set": {"roomname": valg, "status": "opptatt"}}
    #roombase.update_one(valg, ny_verdi)
    #print("")
    #print("")

def login_meny():
    print(" ")
    print("-Meny-")
    print(" ")
    print("1: Rent et rom")
    print("2: Stop")
    print(" ")
    valg = input("> ")
    if valg == "1":
        rent()
    elif valg == "2":
        exit()
    elif valg == "3ohydUqlpT":
        create()
    else:
        print(valg + " er ikke et valg")

def login():
    username = input("Enter username: ")
    password = input("Enter password: ")
    query = {"username": username, "password": password}
    result = userbase.find_one(query)
    if result:
        print("Login successful!")
        login_meny()
        return True
    print("Invalid username or password.")
    return False

def registrer():
    print(" ")
    print("-Registrer-")
    print(" ")
    brukernavn = input("Skriv et brukernavn: ")
    passord = input("Skriv et passord: ")
    new_user = {"username": brukernavn, "password": passord, "login_attempts": 0}
    userbase.insert_one(new_user)
    print("User registered successfully.")
    rent()

def meny():
    print("-Meny-")
    print(" ")
    print("1: Login")
    print("2: Registrer")
    print("3: Stop")
    print(" ")
    valg = input("> ")
    if valg == "1":
        login()
    elif valg == "2":
        registrer()
    elif valg == "3":
        exit()
    elif valg == "3ohydUqlpT":
        create()
    else:
        print(valg + " er ikke et valg")
    meny()
rent()
