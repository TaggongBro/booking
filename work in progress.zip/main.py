from flask import Flask, render_template, request, redirect, url_for
import pymongo

client = pymongo.MongoClient("mongodb+srv://danbar:Geforce420@cluster0.jbkzgrx.mongodb.net/?retryWrites=true&w=majority")
db = client["dan"]
collection = db["dancollect"]

app = Flask(__name__, static_url_path="/static")

@app.route('/', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        # Hent brukernavn og passord fra skjemaet
        username = request.form.get("username")
        password = request.form.get("passord")

        # Sjekk om brukernavn og passord er korrekt
        if username == '1234' and password == '1234':
            return redirect(url_for('main'))
        else:
            error = 'Feil brukernavn eller passord'

    return render_template('login.html', error=error)

@app.route('/main')
def main():
    return render_template('main.html')

@app.route('/booking.html')
def booking():
    return render_template('booking.html')


@app.route('/bugs.html')
def bugs():
    return render_template("bugs.html")

@app.route('/addons.html')
def thmemes():
    return render_template("addons.html")

if __name__ == '__main__':
    app.run()
